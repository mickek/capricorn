# -*- coding: ISO-8859-1 -*-
#############################################
## (C)opyright by Dirk Holtwick, 2002-2008 ##
## All rights reserved                     ##
#############################################

__reversion__ = "$Revision: 247 $"
__author__    = "$Author: holtwick $"
__date__      = "$Date: 2008-08-15 13:37:57 +0200 (Fr, 15 Aug 2008) $"
__version__   = VERSION = "VERSION{3.0.32}VERSION"[8:-8]
__build__     = BUILD   = "BUILD{2009-05-04}BUILD"[6:-6]

VERSION_STR = "pisa %s (Build %s)\n(C) 2002-2009 Dirk Holtwick <dirk.holtwick@gmail.com>, Germany\nWebsite http://www.xhtml2pdf.com" % (
    VERSION,
    BUILD,
    )
